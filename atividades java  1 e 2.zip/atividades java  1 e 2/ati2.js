let pago=document.querySelector("#pago");
let preco=document.querySelector("#preco");
let botao=document.querySelector("#botao");
let resultado=document.querySelector("#resultado"); 
function troco(){
    let pagodigitado=Number(pago.value);
    let precodigitado=Number(preco.value);
    let resultadofinal=pagodigitado-precodigitado;  
    resultado.textContent=resultadofinal;

}
botao.onclick=function(){
    troco()
}

