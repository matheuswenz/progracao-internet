let titulo = document.querySelector("#titulo");
let campotexto = document.querySelector("#campotexto");
let bttrocatexto = document.querySelector("#bttrocatexto");

function trocatexto() {
    //retirando o valor digital do campo de texto
    // e jogando na variavel texto
    let textodigitado = campotexto.value;
    //atribuindo ao texto que foi digitado
    // no input
    titulo.textContent = textodigitado;


}
//atribundo a função ao evento de click do botão
bttrocatexto.onclick = function () {
    trocatexto();
}
