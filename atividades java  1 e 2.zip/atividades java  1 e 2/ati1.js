let numero1=document.querySelector("#numero1");
let numero2=document.querySelector("#numero2");
let botao=document.querySelector("#botao");
let resultado=document.querySelector("#resultado");
function somar(){
    let numero1digitado=Number(numero1.value);
    let numero2digitado=Number(numero2.value);
    let resultadofinal=numero1digitado+numero2digitado;
    resultado.textContent=resultadofinal;
}
butao.onclick=function(){
    somar()
}