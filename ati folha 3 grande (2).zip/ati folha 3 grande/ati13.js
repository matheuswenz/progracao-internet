let raio=document.querySelector("#raio");
let butao=document.querySelector("#butao");
let resultado=document.querySelector("#resultado");
function calcular(){
    let raiodigitado=Number(raio.value);
    let resuldado1= (raiodigitado ** 2) * 3.14;
    resultado.textContent="area " + resuldado1 + "cm²";
    
}
butao.onclick=function(){   
    calcular();
}