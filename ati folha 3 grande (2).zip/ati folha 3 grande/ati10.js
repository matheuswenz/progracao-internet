let dias=document.querySelector("#dias");
let butao=document.querySelector("#butao");
let resultado=document.querySelector("#resultado");
function calcular(){
    let diasdigitados=Number(dias.value);
    let resuldado1= Math.floor (diasdigitados % 365 / 30);
    let resuldado2= Math.floor  (diasdigitados / 365);
    let resuldado3= Math.floor (diasdigitados % 30);
    let resultadoFinal= resuldado3 + " " + "dias " + " " + resuldado1 + " " + "meses" + " " + resuldado2 + " " + "anos";
    resultado.textContent=resultadoFinal;
}
butao.onclick=function(){
    calcular();
}