let salario=document.querySelector("#salario");
let butao=document.querySelector("#butao");
let resultado=document.querySelector("#resultado");
let resultado1=document.querySelector("#resultado1");
let resultado2=document.querySelector("#resultado2");
function calcular(){
    let salariodigitado=Number(salario.value);
    let resuldado1= (salariodigitado * 1.15);
    let resuldado2= (resuldado1 * 0.92);
    let resultado0= (salariodigitado);
    resultado.textContent="salario bruto " + resultado0;
    resultado1.textContent="salario aumentado " + resuldado1;
    resultado2.textContent="salario menos inposto " + resuldado2;
}
butao.onclick=function(){
    calcular();
}