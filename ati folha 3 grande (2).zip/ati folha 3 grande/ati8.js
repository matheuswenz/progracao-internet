let pequeno=document.querySelector("#pequeno");
let medio=document.querySelector("#medio");
let grande=document.querySelector("#grande");
let butao=document.querySelector("#butao");
let resultado=document.querySelector("#resultado");
function calcular(){
    let peqdigitado=Number(pequeno.value);
    let meddigitado=Number(medio.value);
    let grandigitado=Number(grande.value);
    let resultadoFinal=(peqdigitado*10) + (meddigitado*12) + (grandigitado*15)
    resultado.textContent= " R$" + resultadoFinal + " arrecadado";  
}
    
butao.onclick=function(){
    calcular();
}