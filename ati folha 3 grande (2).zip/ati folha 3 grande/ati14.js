let valor=document.querySelector("#valor");
let butao=document.querySelector("#butao");
let resultado=document.querySelector("#resultado");
let resultado1=document.querySelector("#resultado1");

function calcular(){
    let valordigitado=Number(valor.value);
    let resuldado0= Math.floor (valordigitado / 3);
    let resuldadof= valordigitado - ( 2 * resuldado0);
    resultado.textContent= " carlos e andrade " + resuldado0;
    resultado1.textContent= " felipe " + resuldadof;
    
}
butao.onclick=function(){
    calcular();
}