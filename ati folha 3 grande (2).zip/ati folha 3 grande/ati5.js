let preco=document.querySelector("#preco");
let pago=document.querySelector("#pago");
let butao=document.querySelector("#butao");
let resultado=document.querySelector("#resultado");
function calcular(){
    let precodigitado=Number(preco.value);
    let pagodigitado=Number(pago.value);
    let resultadoFinal= pagodigitado / precodigitado;
    resultado.textContent=resultadoFinal + " litros ";
}
butao.onclick=function(){
    calcular();
}