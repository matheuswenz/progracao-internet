let numero=document.querySelector("#numero");
let butao=document.querySelector("#butao");
let resultado=document.querySelector("#resultado");
let resultado1=document.querySelector("#resultado1");
let resultado2=document.querySelector("#resultado2");
function calcular(){
    let numerodigitado=Number(numero.value);
    let resuldado1=Math.floor (numerodigitado / 100); ;
    let resuldado2=Math.floor ( (numerodigitado % 100) / 10); ;
    let resultado0= (numerodigitado % 10); ;
    resultado1.textContent="centena " + resuldado1;
    resultado2.textContent="dezena " + resuldado2;
    resultado.textContent="unidade " + resultado0;
}
butao.onclick=function(){
    calcular();
}
   