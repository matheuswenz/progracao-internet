let nome=document.querySelector("#nome");
let idade=document.querySelector("#idade");
let butao=document.querySelector("#butao");
let resultado=document.querySelector("#resultado");
function calcular(){
    let nomeDigitado=nome.value;
    let idadeDigitada=Number(idade.value);
    let resultadoFinal=idadeDigitada*365;
    resultado.textContent=nomeDigitado + " voce ja viveu " + resultadoFinal + " dias";
}
butao.onclick=function(){
    calcular();
}