
let numero2=document.querySelector("#numero2");
let numero3=document.querySelector("#numero3");
let botao=document.querySelector("#botao");
let resultado=document.querySelector("#resultado");
 function mult(){
   
    let numero2digitado=Number(numero2.value);
    let numero3digitado=Number(numero3.value);
    let resultadofinal=numero2digitado*numero3digitado;
    resultado.textContent=resultadofinal;   
 }
 botao.onclick=function(){
    mult()}