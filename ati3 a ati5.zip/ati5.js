let numero1=document.querySelector("#numero1");
let numero2=document.querySelector("#numero2");
let numero3=document.querySelector("#numero3");
let botao=document.querySelector("#botao");

let resultadoA=document.querySelector("#resultadoA");
let resultadoB=document.querySelector("#resultadoB");
let resultadoC=document.querySelector("#resultadoC");
let resultadoD=document.querySelector("#resultadoD");
function muitoloko(){
    let numero1digitado=Number(numero1.value);
    let numero2digitado=Number(numero2.value);
    let numero3digitado=Number(numero3.value);
    let resultado1=numero1digitado+numero2digitado+numero3digitado;
    let resultadofinal=resultado1/3;
    resultadoA.textContent=resultadofinal;   
}
function muitoloko2(){
    let numero1digitado=Number(numero1.value);
    let numero2digitado=Number(numero2.value);
    let numero3digitado=Number(numero3.value);
    let p1 = 3;
    let p2 = 2;
    let p3 = 5;
    let resultado1=numero1digitado*p1+numero2digitado*p2+numero3digitado*p3;
    let resultadofinal=resultado1/(p1+p2+p3);
    resultadoB.textContent=resultadofinal;
}
function muitoloko3(){
    let resultadoAdigitado=Number(resultadoA.textContent);
    let resultadoBdigitado=Number(resultadoB.textContent);
    let resultadofinal=resultadoAdigitado+resultadoBdigitado;
    resultadoC.textContent=resultadofinal;

}
function muitoloko4(){  
    let resultadoAdigitado=Number(resultadoA.textContent);
    let resultadoBdigitado=Number(resultadoB.textContent);
    let resultadoCdigitado=Number(resultadoC.textContent);
    let resultadofinal=(resultadoAdigitado+resultadoBdigitado+resultadoCdigitado) /3;
    resultadoD.textContent=resultadofinal;
}

botao.onclick=function(){
    muitoloko()
    muitoloko2()
    muitoloko3()
    muitoloko4()
}
