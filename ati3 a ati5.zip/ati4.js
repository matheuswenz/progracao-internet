let valor1=document.querySelector("#valor1");
let botao=document.querySelector("#botao");
let resultado=document.querySelector("#resultado");
function porcentagem(){
    let valor1digitado=Number(valor1.value);
    let valor2digitado=valor1digitado*0.01;
    let resultadofinal=valor1digitado+valor2digitado;
    resultado.textContent=resultadofinal;   
}
botao.onclick=function(){
    porcentagem()}