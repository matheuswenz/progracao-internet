let n1=document.querySelector("#butao1");
let n2=document.querySelector("#butao2");
let n5=document.querySelector("#butao5");
let n10=document.querySelector("#butao10");
let dolar=document.querySelector("#dolar");
let resultado=document.querySelector("#resultado");
function calcular(){
    let dolardigitado=Number(dolar.value);
    let resultadofinal=dolardigitado+(dolardigitado*(1/100)); 
    resultado.textContent=resultadofinal;

}
function calcular2(){
    let dolardigitado=Number(dolar.value);
    let resultadofinal=dolardigitado+(dolardigitado*(2/100)); 
    resultado.textContent=resultadofinal;

}
function calcular5(){
    let dolardigitado=Number(dolar.value);
    let resultadofinal=dolardigitado+(dolardigitado*(5/100)); 
    resultado.textContent=resultadofinal;}
    function calcular10(){
        let dolardigitado=Number(dolar.value);
        let resultadofinal=dolardigitado+(dolardigitado*(10/100)); 
        resultado.textContent=resultadofinal;}


butao1.onclick=function() {
    calcular();
}
butao2.onclick=function() {
    calcular2();
}
butao5.onclick=function() {
    calcular5();
}
butao10.onclick=function() {
    calcular10();
}