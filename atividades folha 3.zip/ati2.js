let n1=document.querySelector("#pessoas")
let butao1=document.querySelector("#butao1")
let resultadoO=document.querySelector("#resultadoO")
let resultadoQ=document.querySelector("#resultadoQ")
 function calcular1(){
    let n1digitado=Number(n1.value);
    let resultadoOfinal=n1digitado*2; 
    resultadoO.textContent=resultadoOfinal;

 }
 function calcular2(){
    let n1digitado=Number(n1.value);
    let resultadoQfinal=n1digitado*50; 
    resultadoQ.textContent=resultadoQfinal+"gramas";

 }
    butao1.onclick=function() {
        calcular1()
        calcular2()
    }