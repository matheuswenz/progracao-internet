let s1=document.querySelector("#s1")
let s2=document.querySelector("#s2")
let s3=document.querySelector("#s3")
let s4=document.querySelector("#s4")
let refri=document.querySelector("#refri")
let butao=document.querySelector("#butao")
let resultado=document.querySelector("#resultado")
function calcular(){
    let s1digitado=n
    
}