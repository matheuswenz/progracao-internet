let n1=document.querySelector("#n1");
let n2=document.querySelector("#n2");
let butao=document.querySelector("#butao");
let r1=document.querySelector("#resultadosoma");
let r2=document.querySelector("#resultadosub");
let r3=document.querySelector("#resultadomult");
let r4=document.querySelector("#resultadodivi");
function calcular(){
    let n1digitado=Number(n1.value);
    let n2digitado=Number(n2.value);
    let resultadoSoma=n1digitado+n2digitado; 
    r1.textContent=resultadoSoma;
    let resultadoSub=n1digitado-n2digitado; 
    r2.textContent=resultadoSub;
    let resultadoMult=n1digitado*n2digitado; 
    r3.textContent=resultadoMult;
    let resultadoDivi=n1digitado/n2digitado; 
    r4.textContent=resultadoDivi;
}
butao.onclick=function() {
    calcular()
}