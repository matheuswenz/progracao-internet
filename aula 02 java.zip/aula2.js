let s1=document.querySelector("#s1")
let s2=document.querySelector("#s2")


let butao=document.querySelector("#butao")
let resultado=document.querySelector("#resultado")
function aula(){
    let s1digitado =Number(s1.value); 
    let s2digitado =Number(s2.value); 
    let media = (s1digitado + s2digitado) / 2;
    // aprovado = media >= 6 ? "Aprovado" : 
    // reprovado = media <= 6 ?  "Reprovado";
    if(media >= 6.0){
        resultado.textContent="Aprovado"

    }else{
        resultado.textContent="Reprovado"
    }

    
    
}
butao.onclick=function() {
    aula()
}