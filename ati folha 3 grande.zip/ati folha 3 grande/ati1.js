let largura=document.querySelector("#largura");
let altura=document.querySelector("#altura");
let butao=document.querySelector("#butao");
let resultado=document.querySelector("#resultado");
function calcular(){
    let larguraDigitada=Number(largura.value);
    let alturaDigitada=Number(altura.value);
    let resultadoFinal=larguraDigitada*alturaDigitada;
    resultado.textContent=resultadoFinal + " m²";
}
butao.onclick=function(){
    calcular();
}