let pao=document.querySelector("#pao");
let broa=document.querySelector("#broa");
let butao=document.querySelector("#butao");
let resultado=document.querySelector("#resultado");
let resultado2=document.querySelector("#resultado2");
function calcular(){ 
    let paodigitado=Number(pao.value);
    let broadigitado=Number(broa.value);
    let resultadoFinal=(paodigitado*0.12) + (broadigitado*1.50)
    resultado.textContent= " R$" + resultadoFinal;  
    let resultadoFinal2= resultadoFinal * 0.10 
    resultado2.textContent= " R$" + resultadoFinal2;
    
}
butao.onclick=function(){
    calcular();
}