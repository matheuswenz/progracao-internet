let quilos=document.querySelector("#quilos");
let butao=document.querySelector("#butao");
let resultado=document.querySelector("#resultado");
function calcular(){
    let quilosdigitados=Number(quilos.value);
    let resultadoFinal= quilosdigitados * 12;
    resultado.textContent=resultadoFinal + " " +"reais a pagar";
}
butao.onclick=function(){
    calcular();
}