let dias=document.querySelector("#dias");
let mes=document.querySelector("#mes");
let butao=document.querySelector("#butao");
let resultado=document.querySelector("#resultado");
function calcular(){
    let diasdigitados=Number(dias.value);
    let mesdigitado=Number(mes.value);
    let resultadoFinal= (mesdigitado*30) + diasdigitados;
    resultado.textContent=resultadoFinal + " dias passados";
    
}
 butao.onclick=function(){
    calcular(); 
}