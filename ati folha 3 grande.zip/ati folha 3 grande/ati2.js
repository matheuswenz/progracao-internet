let cavalos=document.querySelector("#cavalos");
let butao=document.querySelector("#butao");
let resultado=document.querySelector("#resultado");
function calcular( ){
    let cavalosdigitados=Number(cavalos.value);
    let resultadoFinal=cavalosdigitados*4 ;
    resultado.textContent=resultadoFinal + " " +"numero de ferraduras";
}
butao.onclick=function(){
    calcular();
}