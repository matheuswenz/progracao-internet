x2=document.querySelector("#x2");
x1=document.querySelector("#x1");
y1=document.querySelector("#y1");
y2=document.querySelector("#y2");
butao=document.querySelector("#butao");
resultado=document.querySelector("#resultado");
function calcular(){
    let x1digitado=Number(x1.value);
    let x2digitado=Number(x2.value);
    let y1digitado=Number(y1.value);
    let y2digitado=Number(y2.value);
    let resultadoFinal= ((x2digitado-x1digitado) * 2) + ( (y2digitado-y1digitado) * 2);
    let resultadoFinal2= Math.sqrt(resultadoFinal);
    resultado.textContent=resultadoFinal2 + " " + "metros";
    
}
butao.onclick=function(){
    calcular();
}