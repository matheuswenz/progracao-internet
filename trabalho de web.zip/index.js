let nivel=document.getElementById("nivel");
let aulas=document.getElementById("aulas");
let calcularSalarioProfessor=document.getElementById("calcularSalarioProfessor");
let resProfessor=document.getElementById("resProfessor");
function calcularSalario21(){
    let nivelDigitado=Number(nivel.value);
    let aulasDigitadas=Number(aulas.value);
    let salarioFinal=0;
    if(nivelDigitado==1){
        salarioFinal=aulasDigitadas*12.50;
    }else if(nivelDigitado==2){
        salarioFinal=aulasDigitadas*17.00;
    }else if(nivelDigitado==3){
        salarioFinal=aulasDigitadas*25.00;
    
    }else{
        resProfessor.textContent="Nível inválido";
        return;
    }
    resProfessor.textContent= salarioFinal * aulasDigitadas * 4.5;
}
calcularSalarioProfessor.onclick=function(){
    calcularSalario21();
}
let precoProduto=document.getElementById("precoProduto");
let pagamento=document.getElementById("pagamento");
let calcularvenda=document.getElementById("calcularvenda");
let resVenda=document.getElementById("resVenda");
function calcularvVenda(){
    let precoDigitado=Number(precoProduto.value);
    let pagamentoDigitado=pagamento.value;
    let pagamentofinal=0;
    if(pagamentoDigitado=="A"){
       pagamentofinal= precoDigitado - (precoDigitado * (10/100));
    }else if(pagamentoDigitado=="B"){
        pagamentofinal= precoDigitado - (precoDigitado * (15/100));
    }else if(pagamentoDigitado=="C"){
       pagamentofinal= (precoDigitado/2);
    }else if(pagamentoDigitado=="D"){
        pagamentofinal= (precoDigitado * 1.10)/2;
    }
    resVenda.textContent= "O valor final da venda é: R$" + pagamentofinal;
}
calcularVenda.onclick=function(){
    calcularvVenda();
}
//imposto veiculo

let ano = document.querySelector("#ano");
let valorCarro = document.querySelector("#valorCarro");
let calcularImposto = document.querySelector("#calcularImposto");
let resImposto = document.querySelector("#resImposto");

//reajuste de salario

let salario = document.querySelector("#salario");
let cargo = document.querySelector("#cargo");
let calcularSalario = document.querySelector("#calcularSalario");
let resSalario = document.querySelector("#resSalario");

//imposto veiculo

function calcularImpostoVeiculo(){
    let num1 = Number(ano.value);
    let num2 = Number(valorCarro.value);
    let c1lc = num2 * 0.01;
    let c3lc = num2 * 0.015;
    if(num1 < 1990) {
        c2lc = num2 + c1lc;
    }
    else {
        c2lc = num2 + c3lc;
    }

    c4lc = c2lc - num2

    resImposto.textContent = "imposto a ser pago:"+c4lc+" total:"+c2lc;
}

calcularImposto.onclick = function(){
    calcularImpostoVeiculo();
}

//reajuste de salario

function reajusteSalario(){
    let num1 = Number(salario.value);
    let num2 = cargo.value;
    let c1lc = num1 * 0.1;
    let c2lc = num1 * 0.2;
    let c3lc = num1 * 0.3;
    let c4lc = num1 * 0.4;

    if(num2 === "101") {
        result = num1 + c1lc;
    }
    else if(num2 === "102") {
        result = num1 + c2lc;
    }
    else if(num2 === "103") {
        result = num1 + c3lc;
    }
    else {
        result = num1 + c4lc;
    }

    c5lc = result - num1;

    resSalario.textContent = "salario antigo:"+num1+" salario atual:"+result+" diferenca:"+c5lc;
}

calcularSalario.onclick = function(){
    reajusteSalario();
}
let codigo = document.querySelector ("#codigo")
let quantidade = document.querySelector ("#quantidade")
let calcularLanche = document.querySelector ("#calcularLanche")
let resLanche = document.querySelector ("#resLanche")
let saldo = document.querySelector ("#saldo")
let bttcalcular = document.querySelector ("#bttcalcular")
let resCredito = document.querySelector ("#resCredito")



function calccreditobancario (){
    let saldomedio = Number (saldo.value)
    if (saldomedio<200){
        resCredito.textContent="Nenhum Crédito"
    }
    else if (saldomedio<400){
        resCredito.textContent = "seu Limite é "+(saldomedio/100*20)
    }
    else if (saldomedio<600){
        resCredito.textContent = "Seu Limite é "+(saldomedio/100*30)
    }
    else {resCredito.textContent = "Seu Limite é "+(saldomedio/100*40)}
    }
   

bttcalcular.onclick = function(){
    calccreditobancario()
}

function calcularpedido (){
    let selecao = codigo.value
    let quantidadepedido = Number (quantidade.value)
    if (selecao == "Cachorro Quente"){
        resLanche.textContent = "Seu Pedido deu R$:"+(quantidadepedido*11)
    }
    else if (selecao == "Bauru"){
        resLanche.textContent = "Seu Pedido deu R$:"+(quantidadepedido*8.5)
    }
    else if (selecao == "Misto Quente"){
        resLanche.textContent = "Seu Pedido deu R$:"+(quantidadepedido*8)
    }
    else if (selecao == "Hamburguer"){
        resLanche.textContent = "Seu Pedido deu R$:"+(quantidadepedido*9)
    }
    else if (selecao == "Cheeseburger"){
        resLanche.textContent = "Seu Pedido deu R$:"+(quantidadepedido*10)
    }
    else {
        resLanche.textContent = "Seu Pedido deu R$:"+(quantidadepedido*4.5)
    }

}

calcularLanche.onclick = function (){
    calcularpedido ()
}